def set_path():
    pass